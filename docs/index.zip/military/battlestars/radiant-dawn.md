# Radiant Dawn

| Field | Detail |
|---|---|
| Faction | Helios Sovereignty |
| Controlling House | House Aerin-Payne |
| Estimated Crew | 96,000 |
| Embarked Mechs | 4,400 |
| Status | Active |
| Origin | Golden Empire relic |

Radiant Dawn is the Sovereignty's grandest surviving Battlestar, a glittering projection of wealth, prestige, and strategic power.

## Overview

Radiant Dawn is one of the surviving Battlestars of the Core. Like all vessels of its class, it predates the modern Great Houses and cannot be replaced by current shipyards.

Its continued operation depends on generations of engineers, naval crews, scavenged Imperial components, and carefully guarded maintenance rites.

## Strategic Role

Radiant Dawn serves as a fleet flagship, mobile fortress, and command platform. In wartime it may coordinate planetary invasions, border defense operations, or major punitive campaigns.

When the vessel enters a system, it signals that Helios Sovereignty considers the crisis a matter of national importance.

## Known History

TODO: Add known campaigns, famous commanders, refits, disasters, and moments where Radiant Dawn changed the outcome of a war.

## Notable Commanders

TODO: Add admirals, captains, House nobles, or StarCom observers associated with the vessel.

## Current Status

TODO: Add current deployment, home port, strategic assignment, and any known damage or modernization efforts.
